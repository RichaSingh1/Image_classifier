# Flower-Classifier-Tensorflow
Some relevant resources about the Classifier
https://www.youtube.com/watch?v=TKkDOsaqJvw&list=PLArFyb0P44yebE6ezGbu7Wis3er2q5_aE&index=3&t=107s
